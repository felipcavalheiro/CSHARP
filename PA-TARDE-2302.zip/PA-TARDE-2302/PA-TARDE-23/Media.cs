﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PA_TARDE_23
{
    public partial class Media : Form
    {
        public Media()
        {
            InitializeComponent();
        }

        private void Media_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double nota1 = Convert.ToDouble(textBox1.Text);
                double nota2 = Convert.ToDouble(textBox2.Text);
                double nota3 = Convert.ToDouble(textBox3.Text);

                double media = (nota1 + nota2 + nota3) / 3;

                label5.Text = media.ToString("0.00");

                if (media >= 7)
                {
                    label6.ForeColor = System.Drawing.Color.Green;
                    label6.Text = "APROVADO";
                }
                else
                {
                    label6.ForeColor = System.Drawing.Color.Red;
                    label6.Text = "REPROVADO";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, insira valores válidos para as notas.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form1 voltar = new Form1();
            voltar.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            label5.Text = " ";
            label6.Text = " ";

        }
    }
}
