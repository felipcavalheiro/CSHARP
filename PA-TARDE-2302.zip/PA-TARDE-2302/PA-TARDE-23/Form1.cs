namespace PA_TARDE_23
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Instancia o novo formul�rio de c�lculo de m�dia
            /*CalculadoraMediaForm calculadoraMediaForm = new CalculadoraMediaForm();

            // Mostra o novo formul�rio como um di�logo
            calculadoraMediaForm.ShowDialog();*/

            Media media = new Media();
            media.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Temperatura temperatura = new Temperatura();
            temperatura.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Resistencia resistencia = new Resistencia();
            resistencia.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Combustivel combustivel = new Combustivel();
            combustivel.Show();
            this.Hide();
        }
    }
}